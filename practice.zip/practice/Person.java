package in.java.practice;

public class Person {
	
	private String name;
	private int age;
	
	//getter method
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	
	//setter method
	public void setName(String n) {
		name = n;
	}
	public void setAge(int a) {
		age = a;
	}
	

}
