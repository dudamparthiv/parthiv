package in.java.practice;

public class LocalVariable {

	public static void main(String[] args) {
		String name = "asdf"; // local variable which can only run in {} public static void main
		System.out.print(name);
		
		// Output : asdf

	}
	
	// default value of local variable
	
	/*public static void main(String[] args) {
		String name ;// local variable
		// no default for local variable give an error
		System.out.print(name);
		
//		Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
//			The local variable name may not have been initialized
//
//			at javaPractice/in.java.practice.LocalVariable.main(LocalVariable.java:17)
		

	}*/

}
