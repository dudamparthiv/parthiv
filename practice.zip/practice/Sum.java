class Sum{
    public static void main(String args[]){
        //int i = 23;
        //int i = 33;
        //int i = 56;
        //int i = 456;
        int i = 1245;
        int sum;
        for(sum = 0;i > 0 || sum >9;i /= 10){
            if(i == 0){
                i=sum;
                sum=0;
            }
            sum += i % 10;
        }
        System.out.println("sum = " + sum);   
    }
}
// Output :
    // sum = 5   //for i = 23
    // sum = 6   //for i = 33
    // sum = 2   //for i = 56
    // sum = 6   //for i = 456
    // sum = 3   //for i = 1245