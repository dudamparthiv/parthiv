package in.java.practice;

public class ParametarizedConst {
	
	private String languages;
	
	ParametarizedConst(String lang){  // parametarized constructor
		languages = lang;
		System.out.println(languages);
	}
	

}
