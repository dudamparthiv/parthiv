class NestedIf{
    public static void main(String args[]){
        int a = 10 , b = 20 ;
        if( a == 10){
            if(b == 30){
                System.out.println("a = " + a);
                System.out.println("a = " + a);   
            }
            else{
                System.out.println("a = " + a);
            }
        }
        else{
            System.out.println("b = " + b);   
        }
    }
}
// Output :
    // a = 10