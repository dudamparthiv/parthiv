package in.java.practice;

public class InstanceVariable {
	
	private int i = 10; // Instance variable

	public static void main(String[] args) {
		
		InstanceVariable obj = new InstanceVariable();
		InstanceVariable obj1 = new InstanceVariable();
		InstanceVariable obj2 = new InstanceVariable();
		
		//access the instance variable
		System.out.println(obj.i);
		System.out.println(obj1.i);
		System.out.println(obj2.i);
		
		System.out.println(++obj.i);
		System.out.println(obj1.i);
		System.out.println(--obj2.i);

	}

}
//Output:
//	10
//	10
//	10
//	11
//	10
//	9
