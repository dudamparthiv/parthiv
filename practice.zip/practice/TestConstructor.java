package in.java.practice;

public class TestConstructor {

	public static void main(String[] args) {
		
		//classname objname = new constructor name
		Constructor p1 = new Constructor();
		String name = p1.getName();
		System.out.println(name);
		
	
	}

}
