package in.java.practice;

public class StaticVariable {
	
	private static int i = 20; // static variable

	public static void main(String[] args) {
		
		//access static variable
		int a = StaticVariable.i;
		int b = StaticVariable.i++;
		int c = StaticVariable.i;
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}

}
//Output:
	//20
	//20
	//21
